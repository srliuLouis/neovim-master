This grammar demonstrates that you can have an inlined rule that contains another inlined rule.
